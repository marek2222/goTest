// Copyright © 2016 Alan A. A. Donovan & Brian W. Kernighan.
// License: https://creativecommons.org/licenses/by-nc-sa/4.0/


// Helloworld to nasz pierwszy program Go.
//!+
package main

import "fmt"

func main() {
	fmt.Println("Witaj, 世界")
}

//!-
